$ErrorActionPreference = 'Continue'
$root = 'f:\Water Guardian System'
$out  = Join-Path $root '_browsers.txt'
$lines = New-Object System.Collections.Generic.List[string]

$lines.Add("=== BROWSER AVAILABILITY ===")
$cands = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Mozilla Firefox\firefox.exe",
  "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe"
)
$found = $null
foreach ($c in $cands) {
    $exists = Test-Path -LiteralPath $c
    $lines.Add(("  {0,-70} {1}" -f $c, $exists))
    if ($exists -and -not $found) { $found = $c }
}

$lines.Add("")
$lines.Add("FOUND_BROWSER: " + $(if($found){$found}else{'NONE'}))

$lines | Out-File -LiteralPath $out -Encoding utf8
Write-Host "browsers done"
