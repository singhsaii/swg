$ErrorActionPreference = 'Continue'
$root = 'f:\Water Guardian System'
$out  = Join-Path $root '_probe.txt'

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("=== DIRECTORY (re-list) ===")
Get-ChildItem -LiteralPath $root -Force | ForEach-Object {
    $lines.Add(("{0,-12} {1,10}  {2}" -f $_.Mode, $_.Length, $_.Name))
}

$lines.Add("")
$lines.Add("=== .clinerules.txt raw bytes ===")
$rules = Join-Path $root '.clinerules.txt'
if (Test-Path -LiteralPath $rules) {
    $bytes = [System.IO.File]::ReadAllBytes($rules)
    $lines.Add("Length: " + $bytes.Length)
    $lines.Add("Hex: " + (($bytes | Select-Object -First 64 | ForEach-Object { $_.ToString('X2') }) -join ' '))
    if ($bytes.Length -gt 0) {
        $lines.Add("Text:")
        $lines.Add([System.Text.Encoding]::UTF8.GetString($bytes))
    }
}

$lines.Add("")
$lines.Add("=== .clinerules (directory form?) ===")
$d = Join-Path $root '.clinerules'
if (Test-Path -LiteralPath $d) {
    $lines.Add("DIR EXISTS")
    Get-ChildItem -LiteralPath $d -Recurse -Force | ForEach-Object { $lines.Add("  " + $_.FullName + "  (" + $_.Length + ")") }
} else {
    $lines.Add("no .clinerules directory")
}

$lines.Add("")
$lines.Add("=== Toolchain ===")
foreach ($cmd in @('node','npm','python','py','git','code','dotnet')) {
    $c = Get-Command $cmd -ErrorAction SilentlyContinue
    if ($c) {
        try {
            $v = (& $cmd --version 2>&1 | Select-Object -First 1)
        } catch { $v = 'n/a' }
        $lines.Add(("{0,-10} FOUND  {1}  ({2})" -f $cmd, $v, $c.Source))
    } else {
        $lines.Add(("{0,-10} MISSING" -f $cmd))
    }
}

$lines | Out-File -LiteralPath $out -Encoding utf8
