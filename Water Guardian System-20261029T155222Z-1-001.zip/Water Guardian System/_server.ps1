# Minimal static file server using System.Net.Sockets.TcpListener.
# We avoid HttpListener because binding a prefix on Windows requires an
# admin URL-ACL reservation; TcpListener needs no privileges.
param(
    [string]$Root = 'C:\swg_test',
    [int]$Port = 8731
)

$ErrorActionPreference = 'Stop'
$rootFull = (Resolve-Path -LiteralPath $Root).Path.TrimEnd('\')
$prefix = "http://127.0.0.1:$Port/"

$mime = @{
    '.html'='text/html; charset=utf-8'; '.css'='text/css; charset=utf-8'
    '.js'='text/javascript; charset=utf-8'; '.json'='application/json'
    '.png'='image/png'; '.svg'='image/svg+xml'; '.ico'='image/x-icon'
}

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
$listener.Start()
Write-Host "SERVING $rootFull at $prefix"

function Send-Response($stream, [int]$status, [string]$statusText, [byte[]]$body, [string]$contentType) {
    $header = "HTTP/1.1 $status $statusText`r`n" +
              "Content-Type: $contentType`r`n" +
              "Content-Length: $($body.Length)`r`n" +
              "Connection: close`r`n`r`n"
    $head = [System.Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($head, 0, $head.Length)
    if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
    $stream.Flush()
}

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII)
            $reqLine = $reader.ReadLine()
            while ($true) {
                $h = $reader.ReadLine()
                if ([string]::IsNullOrEmpty($h)) { break }
            }

            $rel = '/'
            if ($reqLine) {
                $parts = $reqLine -split '\s+'
                if ($parts.Count -ge 2) { $rel = $parts[1] }
            }
            $rel = ($rel -split '\?')[0]
            $rel = [System.Uri]::UnescapeDataString($rel).TrimStart('/')
            if ([string]::IsNullOrWhiteSpace($rel)) { $rel = 'index.html' }

            $path = Join-Path $rootFull ($rel -replace '/','\')
            if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
                $b = [System.Text.Encoding]::UTF8.GetBytes("Not found: $rel")
                Send-Response $stream 404 'Not Found' $b 'text/plain; charset=utf-8'
            } else {
                $ext = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
                $ct = if ($mime.ContainsKey($ext)) { $mime[$ext] } else { 'application/octet-stream' }
                $b = [System.IO.File]::ReadAllBytes($path)
                Send-Response $stream 200 'OK' $b $ct
            }
        } catch {
            Write-Host "REQUEST ERROR: $($_.Exception.Message)"
        } finally {
            try { $client.Close() } catch {}
        }
    }
}
finally {
    $listener.Stop()
}

