$ErrorActionPreference = 'Stop'
$work = 'C:\swg_diag'
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory -Path $work -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $work 'assets\js') -Force | Out-Null

Copy-Item 'f:\Water Guardian System\assets\js\*.js' (Join-Path $work 'assets\js') -Force

Set-Content -LiteralPath "$work\diag.html" -Value @'
<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<pre id="r">PENDING</pre>
<script>
function show(t){ document.getElementById('r').textContent = t; }
fetch('assets/js/app.js').then(function(r){ return r.text(); }).then(function(t){
  var lines = t.split(/\r?\n/);
  var out = [];
  out.push('LEN=' + t.length + ' LINES=' + lines.length);
  // look for stray control chars
  var ctrl = [];
  for (var i=0;i<t.length;i++){
    var c = t.charCodeAt(i);
    if (c < 32 && c !== 9 && c !== 10 && c !== 13) { ctrl.push(i + ':' + c); }
  }
  out.push('CTRL_CHARS(' + ctrl.length + ')=' + ctrl.slice(0,20).join(','));
  try {
    (new Function(t))();
    out.push('PARSE_OK');
  } catch (e) {
    out.push('PARSE_ERROR: ' + e.name + ': ' + e.message);
    if (e.stack) out.push('STACK=' + e.stack.split('\n').slice(0,4).join(' >> '));
  }
  show(out.join('\n'));
}).catch(function(e){ show('FETCH_ERROR ' + e.message); });
</script>
</body></html>
'@ -Encoding utf8

$chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
function Quote-Arg([string]$a) { if ($a -notmatch '[\s"]') { return $a }; return '"' + $a + '"' }
function Run-Chrome([string[]]$a, [string]$outFile) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $chrome
    $psi.Arguments = (($a | ForEach-Object { Quote-Arg $_ }) -join ' ')
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $so = $p.StandardOutput.ReadToEnd(); $se = $p.StandardError.ReadToEnd()
    $p.WaitForExit(60000) | Out-Null
    if (-not $p.HasExited) { try { $p.Kill() } catch {} }
    Set-Content -LiteralPath $outFile -Value $so -Encoding utf8
    Set-Content -LiteralPath ($outFile -replace '\.txt$','.err.txt') -Value $se -Encoding utf8
}

$prof = "$work\p1"
Run-Chrome @('--headless=new','--disable-gpu','--no-sandbox','--disable-dev-shm-usage','--allow-file-access-from-files',"--user-data-dir=$prof",'--virtual-time-budget=8000','--dump-dom','file:///C:/swg_diag/diag.html') "$work\diag_out.txt"

# also capture raw bytes info via PowerShell
$raw = [System.IO.File]::ReadAllBytes('f:\Water Guardian System\assets\js\app.js')
$info = New-Object System.Collections.Generic.List[string]
$info.Add('BYTES=' + $raw.Length)
$info.Add('BOM=' + (($raw[0..2] | ForEach-Object { $_.ToString('X2') }) -join ' '))
$cr = 0; $lf = 0; $crlf = 0; $lonecr = 0
for ($i=0; $i -lt $raw.Length; $i++) {
    if ($raw[$i] -eq 13) { $cr++; if ($i+1 -lt $raw.Length -and $raw[$i+1] -eq 10) { $crlf++ } else { $lonecr++ } }
    if ($raw[$i] -eq 10) { $lf++ }
}
$info.Add("CR=$cr LF=$lf CRLF=$crlf LONE_CR=$lonecr")
$info | Out-File -LiteralPath 'f:\Water Guardian System\_bytes.txt' -Encoding utf8
Write-Output 'done'
