$ErrorActionPreference = 'Stop'
$work = 'C:\swg_srv'
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory -Path $work -Force | Out-Null

Set-Content -LiteralPath "$work\set.html" -Value @'
<!DOCTYPE html><html><body>
<div id="r">PENDING</div>
<script>
try { localStorage.setItem('swg.session', JSON.stringify({name:'Demo User',email:'demo@gniot.net.in',role:'Facility Administrator'})); }
catch(e) { document.getElementById('r').textContent = 'LS_FAIL ' + e.message; }
</script></body></html>
Start-Sleep -Seconds 2

    # sanity check the server itself
    try {
        $probe = Invoke-WebRequest -Uri 'http://127.0.0.1:8742/read.html' -UseBasicParsing -TimeoutSec 15
        Write-Host "SERVER PROBE: status $($probe.StatusCode) len $($probe.Content.Length)"
    } catch {
        Write-Host "SERVER PROBE FAILED: $($_.Exception.Message)"
    }
'@ -Encoding utf8

Set-Content -LiteralPath "$work\read.html" -Value @'
<!DOCTYPE html><html><body>
<div id="r">PENDING</div>
<script>
var out = [];
try { out.push('LS=' + (localStorage.getItem('swg.session') || 'NULL')); } catch(e) { out.push('LS_FAIL ' + e.message); }
try { out.push('SS=' + (sessionStorage.getItem('swg.session') || 'NULL')); } catch(e) { out.push('SS_FAIL'); }
try { out.push('COOKIE=' + (document.cookie || 'NULL')); } catch(e) { out.push('CK_FAIL'); }
document.getElementById('r').textContent = out.join(' | ');
</script></body></html>
'@ -Encoding utf8

# start server (path has spaces -> embed quotes for -File)
$sp = Start-Process powershell -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','"f:\Water Guardian System\_server.ps1"','-Root',"`"$work`"",'-Port','8742') -PassThru -WindowStyle Hidden -RedirectStandardOutput "$work\srv.log" -RedirectStandardError "$work\srv.err"
Start-Sleep -Seconds 3

try {
    $chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
    function Quote-Arg([string]$a) { if ($a -notmatch '[\s"]') { return $a }; return '"' + $a + '"' }
    function Run-Chrome([string[]]$a, [string]$outFile) {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $chrome
        $psi.Arguments = (($a | ForEach-Object { Quote-Arg $_ }) -join ' ')
        $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
        $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
        $p = [System.Diagnostics.Process]::Start($psi)
        $so = $p.StandardOutput.ReadToEnd(); $se = $p.StandardError.ReadToEnd()
        $p.WaitForExit(45000) | Out-Null
        if (-not $p.HasExited) { try { $p.Kill() } catch {} }
        Set-Content -LiteralPath $outFile -Value ("EXIT=" + $p.ExitCode + "`n" + $so + "`nERR=" + $se) -Encoding utf8
    }

    $prof = "$work\p1"
    Run-Chrome @('--headless=new','--disable-gpu','--no-sandbox','--disable-dev-shm-usage',"--user-data-dir=$prof",'--dump-dom','http://localhost:8742/set.html') "$work\o1.txt"
    Run-Chrome @('--headless=new','--disable-gpu','--no-sandbox','--disable-dev-shm-usage',"--user-data-dir=$prof",'--dump-dom','http://localhost:8742/read.html') "$work\o2.txt"
}
finally {
    try { $sp.Kill() } catch {}
}

Write-Host "--- SET ---"; Get-Content "$work\o1.txt"
Write-Host "--- READ ---"; Get-Content "$work\o2.txt"
