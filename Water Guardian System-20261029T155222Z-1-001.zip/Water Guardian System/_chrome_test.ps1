$ErrorActionPreference = 'Stop'
$chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
$work = 'C:\swg_ct'
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory -Path $work -Force | Out-Null

function Quote-Arg([string]$a) {
    if ($a -notmatch '[\s"]') { return $a }
    return '"' + ($a -replace '(\\*)"','$1$1\"' -replace '(\\+)$','$1$1') + '"'
}

function Run-Chrome([string[]]$a, [string]$outFile) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $chrome
    $psi.Arguments = (($a | ForEach-Object { Quote-Arg $_ }) -join ' ')
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    Write-Host "ARGS: $($psi.Arguments)"
    $p = [System.Diagnostics.Process]::Start($psi)
    $so = $p.StandardOutput.ReadToEnd()
    $se = $p.StandardError.ReadToEnd()
    $p.WaitForExit(60000) | Out-Null
    if (-not $p.HasExited) { try { $p.Kill() } catch {} }
    Set-Content -LiteralPath $outFile -Value ("EXIT=" + $p.ExitCode + "`nSTDOUT_LEN=" + $so.Length + "`nSTDOUT=" + $so + "`nSTDERR=" + $se) -Encoding utf8
}

$testHtml = Join-Path $work 't.html'
Set-Content -LiteralPath $testHtml -Value '<!DOCTYPE html><html><body><div id="r">PENDING</div><script>document.getElementById("r").textContent="JS_RAN_OK";</script></body></html>' -Encoding utf8

Write-Host "--- TEST A: new headless + dump-dom ---"
Run-Chrome @('--headless=new','--disable-gpu','--no-sandbox','--disable-dev-shm-usage',"--user-data-dir=$work\p1",'--dump-dom',"file:///$($testHtml -replace '\\','/')") (Join-Path $work 'a.txt')

Write-Host "--- TEST B: legacy headless + dump-dom ---"
Run-Chrome @('--headless','--disable-gpu','--no-sandbox','--disable-dev-shm-usage',"--user-data-dir=$work\p2",'--dump-dom',"file:///$($testHtml -replace '\\','/')") (Join-Path $work 'b.txt')

Write-Host "--- TEST C: new headless + screenshot ---"
Run-Chrome @('--headless=new','--disable-gpu','--no-sandbox','--disable-dev-shm-usage',"--user-data-dir=$work\p3",'--window-size=800,600',"--screenshot=$work\c.png","file:///$($testHtml -replace '\\','/')") (Join-Path $work 'c.txt')

Write-Host "--- VERSION ---"
Run-Chrome @('--version') (Join-Path $work 'v.txt')
Write-Host "DONE"
