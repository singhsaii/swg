$out = New-Object System.Collections.Generic.List[string]

# 1. VS Code local history
$hist = Join-Path $env:APPDATA 'Code\User\History'
if (Test-Path $hist) {
    $out.Add('=== VS CODE HISTORY MATCHES FOR app.js ===')
    Get-ChildItem $hist -Recurse -Filter 'entries.json' -ErrorAction SilentlyContinue | ForEach-Object {
        $c = Get-Content $_.FullName -Raw -ErrorAction SilentlyContinue
        if ($c -and $c -match 'app\.js') {
            $out.Add('ENTRIES: ' + $_.FullName)
            $out.Add($c)
            $dir = Split-Path $_.FullName -Parent
            Get-ChildItem $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'entries.json' } | ForEach-Object {
                $out.Add('   CAND: ' + $_.FullName + '  len=' + $_.Length + '  mtime=' + $_.LastWriteTime.ToString('s'))
            }
        }
    }
} else {
    $out.Add('NO VS CODE HISTORY DIR: ' + $hist)
}

# 2. Git
$out.Add('')
$out.Add('=== GIT ===')
$gitDir = 'f:\Water Guardian System\.git'
$out.Add('git dir exists: ' + (Test-Path $gitDir))
if (Test-Path $gitDir) {
    $out.Add((git -C 'f:\Water Guardian System' log --oneline -20 2>&1 | Out-String).Trim())
    $out.Add('--- status ---')
    $out.Add((git -C 'f:\Water Guardian System' status --short 2>&1 | Out-String).Trim())
}

# 3. Project inventory
$out.Add('')
$out.Add('=== PROJECT FILES ===')
Get-ChildItem 'f:\Water Guardian System' -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -notlike '*\.git\*' } |
    ForEach-Object { $out.Add(("{0,10}  {1}" -f $_.Length, $_.FullName)) }

$out | Out-File -LiteralPath 'f:\Water Guardian System\_hist2.txt' -Encoding utf8
Write-Output 'ok'
