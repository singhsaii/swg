$ErrorActionPreference = 'Continue'
$root = 'f:\Water Guardian System'
$out  = Join-Path $root '_verify.txt'
$lines = New-Object System.Collections.Generic.List[string]

# ---------- 1. File inventory ----------
$lines.Add("=== FILE INVENTORY ===")
Get-ChildItem -LiteralPath $root -Recurse -File -Force |
  Where-Object { $_.FullName -notlike '*\_pptx\*' -and $_.Name -notlike '_*' } |
  ForEach-Object {
    $lines.Add(("  {0,-46} {1,8} bytes" -f $_.FullName.Replace($root+'\',''), $_.Length))
  }

# ---------- 2. JS structural check ----------
$lines.Add("")
$lines.Add("=== JS STRUCTURAL CHECK ===")
$jsFiles = @('assets\js\icons.js','assets\js\engine.js','assets\js\auth.js','assets\js\app.js')
foreach ($jf in $jsFiles) {
    $p = Join-Path $root $jf
    if (-not (Test-Path -LiteralPath $p)) { $lines.Add("  MISSING: $jf"); continue }
    $t = Get-Content -LiteralPath $p -Raw
    $openB  = ([regex]::Matches($t,'\{')).Count
    $closeB = ([regex]::Matches($t,'\}')).Count
    $openP  = ([regex]::Matches($t,'\(')).Count
    $closeP = ([regex]::Matches($t,'\)')).Count
    $openS  = ([regex]::Matches($t,'\[')).Count
    $closeS = ([regex]::Matches($t,'\]')).Count
    $lines.Add(("  {0,-22} braces {1}/{2}  parens {3}/{4}  brackets {5}/{6}" -f $jf,$openB,$closeB,$openP,$closeP,$openS,$closeS))
    if ($openB -ne $closeB -or $openP -ne $closeP -or $openS -ne $closeS) { $lines.Add("     >>> MISMATCH") }
}

# ---------- 3. HTML asset references ----------
$lines.Add("")
$lines.Add("=== HTML ASSET REFERENCES ===")
foreach ($hf in @('index.html','dashboard.html')) {
    $p = Join-Path $root $hf
    $t = Get-Content -LiteralPath $p -Raw
    foreach ($m in [regex]::Matches($t, '(?:href|src)="([^"]+)"')) {
        $ref = $m.Groups[1].Value
        if ($ref -match '^data:') { continue }
        $target = Join-Path $root $ref
        $ok = Test-Path -LiteralPath $target
        $lines.Add(("  {0,-16} -> {1,-32} {2}" -f $hf, $ref, $(if($ok){'OK'}else{'*** MISSING ***'})))
    }
}

# ---------- 4. CSS custom property check ----------
$lines.Add("")
$lines.Add("=== CSS CUSTOM PROPERTY CHECK ===")
$tokens = Get-Content -LiteralPath (Join-Path $root 'assets\css\tokens.css') -Raw
$defined = @{}
foreach ($m in [regex]::Matches($tokens,'(--[a-z0-9-]+)\s*:')) { $defined[$m.Groups[1].Value] = $true }
$lines.Add("  defined: " + $defined.Count)

$used = @{}
Get-ChildItem -LiteralPath (Join-Path $root 'assets\css') -Filter '*.css' | ForEach-Object {
    $ct = Get-Content -LiteralPath $_.FullName -Raw
    foreach ($m in [regex]::Matches($ct,'var\((--[a-z0-9-]+)')) { $used[$m.Groups[1].Value] = $true }
}
$missing = @()
foreach ($u in $used.Keys) { if (-not $defined.ContainsKey($u)) { $missing += $u } }
$lines.Add("  used: " + $used.Count)
if ($missing.Count -gt 0) { foreach ($mm in $missing) { $lines.Add("  *** UNDEFINED: $mm") } }
else { $lines.Add("  OK - every var() has a definition") }

# ---------- 5. CSS brace balance ----------
$lines.Add("")
$lines.Add("=== CSS BRACE BALANCE ===")
Get-ChildItem -LiteralPath (Join-Path $root 'assets\css') -Filter '*.css' | ForEach-Object {
    $ct = Get-Content -LiteralPath $_.FullName -Raw
    $o = ([regex]::Matches($ct,'\{')).Count
    $c = ([regex]::Matches($ct,'\}')).Count
    $lines.Add(("  {0,-18} {1}/{2} {3}" -f $_.Name,$o,$c,$(if($o -eq $c){'OK'}else{'*** MISMATCH ***'})))
}


# ---------- 6. HTML tag balance ----------
$lines.Add("")
$lines.Add("=== HTML STRUCTURE ===")
foreach ($hf in @('index.html','dashboard.html')) {
    $t = Get-Content -LiteralPath (Join-Path $root $hf) -Raw
    $lines.Add("  -- $hf --")
    $bad = 0
    foreach ($tag in @('div','section','form','button','ul','li','table','tbody','thead','tr','td','th','svg','span','p','a','label','select','option','main','aside','header','article')) {
        $o = ([regex]::Matches($t, "<$tag(\s|>)")).Count
        $c = ([regex]::Matches($t, "</$tag>")).Count
        if ($o -ne $c) { $lines.Add(("     *** {0}: {1} open / {2} close" -f $tag,$o,$c)); $bad++ }
    }
    if ($bad -eq 0) { $lines.Add("     OK - all tags balanced") }
}

# ---------- 7. JS -> HTML ID references ----------
$lines.Add("")
$lines.Add("=== JS -> HTML ID REFERENCES ===")
$idDefs = @{}
foreach ($hf in @('index.html','dashboard.html')) {
    $t = Get-Content -LiteralPath (Join-Path $root $hf) -Raw
    foreach ($m in [regex]::Matches($t,'id="([^"]+)"')) { $idDefs[$m.Groups[1].Value] = $hf }
}
$lines.Add("  ids defined: " + $idDefs.Count)

$jsAll = ($jsFiles | ForEach-Object { Get-Content -LiteralPath (Join-Path $root $_) -Raw }) -join "`n"
$refs = @{}
foreach ($m in [regex]::Matches($jsAll,"\$\('#([a-zA-Z0-9_-]+)'\)")) { $refs[$m.Groups[1].Value] = $true }
foreach ($m in [regex]::Matches($jsAll,"getElementById\('([a-zA-Z0-9_-]+)'\)")) { $refs[$m.Groups[1].Value] = $true }
$badRefs = @()
foreach ($r in $refs.Keys) { if (-not $idDefs.ContainsKey($r)) { $badRefs += $r } }
if ($badRefs.Count -gt 0) { foreach ($b in $badRefs) { $lines.Add("  *** NO SUCH ID: #$b") } }
else { $lines.Add("  OK - all JS id references resolve") }

# ---------- 8. Icon names ----------
$lines.Add("")
$lines.Add("=== ICON NAME CHECK ===")
$icons = Get-Content -LiteralPath (Join-Path $root 'assets\js\icons.js') -Raw
$definedIcons = @{}
foreach ($m in [regex]::Matches($icons,'(?m)^\s{4}([a-zA-Z0-9]+)\s*:')) { $definedIcons[$m.Groups[1].Value] = $true }
$lines.Add("  icons defined: " + $definedIcons.Count)

$usedIcons = @{}
foreach ($f in @('assets\js\app.js','assets\js\engine.js','assets\js\auth.js')) {
    $t = Get-Content -LiteralPath (Join-Path $root $f) -Raw
    foreach ($m in [regex]::Matches($t,"SVG\.icon\('([a-zA-Z0-9]+)'\)")) { $usedIcons[$m.Groups[1].Value] = $true }
}
$missingIcons = @()
foreach ($u in $usedIcons.Keys) { if (-not $definedIcons.ContainsKey($u)) { $missingIcons += $u } }
if ($missingIcons.Count -gt 0) { foreach ($mi in $missingIcons) { $lines.Add("  *** MISSING ICON: $mi") } }
else { $lines.Add("  OK - all SVG.icon() names are defined") }

# ---------- 9. Blueprint figure traceability ----------
$lines.Add("")
$lines.Add("=== BLUEPRINT FIGURE TRACEABILITY ===")
$engine = Get-Content -LiteralPath (Join-Path $root 'assets\js\engine.js') -Raw
$checks = @(
  @{ label='Hostel A baseline 8000'; pat='baseline:\s*8000' },
  @{ label='Hostel A current 12500';  pat='current:\s*12500' },
  @{ label='Score 76/100';            pat='conservationScore:\s*76' },
  @{ label='25000 L/month saved';     pat='waterSavedMonthly:\s*25000' },
  @{ label='RO reject 500 L/day';     pat='rejectWater:\s*500' },
  @{ label='Reuse 400 L/day';          pat='reused:\s*400' },
  @{ label='Warning threshold 15%';   pat='warning:\s*15' },
  @{ label='Critical threshold 30%';  pat='critical:\s*30' },
  @{ label='Overflow 95%';            pat='overflow:\s*95' }
)
foreach ($c in $checks) {
    $hit = [regex]::IsMatch($engine, $c.pat)
    $lines.Add(("  {0,-34} {1}" -f $c.label, $(if($hit){'FOUND'}else{'*** NOT FOUND ***'})))
}

$lines | Out-File -LiteralPath $out -Encoding utf8
Write-Host "verify done"
