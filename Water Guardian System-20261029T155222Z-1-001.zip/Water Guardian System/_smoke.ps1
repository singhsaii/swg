$ErrorActionPreference = 'Continue'
$out = 'f:\Water Guardian System\_smoke.txt'
$lines = New-Object System.Collections.Generic.List[string]

$chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
$work   = 'C:\swg_smoke'

if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path $work -Force | Out-Null

Set-Content -LiteralPath (Join-Path $work 't.html') -Value '<!DOCTYPE html><html><body><h1 id="x">HELLO</h1></body></html>' -Encoding utf8

$prof = Join-Path $work 'prof'

# --- Attempt A: cmd redirection ---
$domA = Join-Path $work 'domA.txt'
$errA = Join-Path $work 'errA.txt'
$cmd  = '"' + $chrome + '" --headless=new --disable-gpu --no-sandbox --disable-dev-shm-usage --user-data-dir="' + $prof + '" --dump-dom "file:///C:/swg_smoke/t.html" > "' + $domA + '" 2> "' + $errA + '"'
cmd /c $cmd
$lines.Add('A exit code: ' + $LASTEXITCODE)
$da = (Get-Content -LiteralPath $domA -Raw -ErrorAction SilentlyContinue)
$lines.Add('A dom length: ' + $da.Length)
$lines.Add('A dom head: ' + $(if ($da) { $da.Substring(0, [Math]::Min(160, $da.Length)) } else { '<empty>' }))
$ea = (Get-Content -LiteralPath $errA -Raw -ErrorAction SilentlyContinue)
$lines.Add('A stderr: ' + $(if ($ea) { $ea.Trim() } else { '<empty>' }))

# --- Attempt B: old headless ---
$domB = Join-Path $work 'domB.txt'
$errB = Join-Path $work 'errB.txt'
$profB = Join-Path $work 'profB'
$cmdB = '"' + $chrome + '" --headless --disable-gpu --no-sandbox --user-data-dir="' + $profB + '" --dump-dom "file:///C:/swg_smoke/t.html" > "' + $domB + '" 2> "' + $errB + '"'
cmd /c $cmdB
$lines.Add('B exit code: ' + $LASTEXITCODE)
$db = (Get-Content -LiteralPath $domB -Raw -ErrorAction SilentlyContinue)
$lines.Add('B dom length: ' + $db.Length)
$lines.Add('B dom head: ' + $(if ($db) { $db.Substring(0, [Math]::Min(160, $db.Length)) } else { '<empty>' }))
$eb = (Get-Content -LiteralPath $errB -Raw -ErrorAction SilentlyContinue)
$lines.Add('B stderr: ' + $(if ($eb) { $eb.Trim() } else { '<empty>' }))

# --- Attempt C: screenshot, new headless ---
$shot = Join-Path $work 'shot.png'
$errC = Join-Path $work 'errC.txt'
$profC = Join-Path $work 'profC'
$cmdC = '"' + $chrome + '" --headless=new --disable-gpu --no-sandbox --hide-scrollbars --window-size=1200,800 --user-data-dir="' + $profC + '" --screenshot="' + $shot + '" "file:///C:/swg_smoke/t.html" > NUL 2> "' + $errC + '"'
cmd /c $cmdC
$lines.Add('C exit code: ' + $LASTEXITCODE)
$lines.Add('C screenshot exists: ' + (Test-Path -LiteralPath $shot))
if (Test-Path -LiteralPath $shot) { $lines.Add('C screenshot bytes: ' + (Get-Item -LiteralPath $shot).Length) }
$ec = (Get-Content -LiteralPath $errC -Raw -ErrorAction SilentlyContinue)
$lines.Add('C stderr: ' + $(if ($ec) { $ec.Trim() } else { '<empty>' }))

$lines | Out-File -LiteralPath $out -Encoding utf8
Write-Host 'smoke done'
