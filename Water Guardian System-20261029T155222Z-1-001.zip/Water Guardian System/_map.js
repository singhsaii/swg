const fs = require('fs');
const src = fs.readFileSync('f:/Water Guardian System/assets/js/app.js', 'utf8');
const lines = src.split(/\r?\n/);
console.log('TOTAL_LINES', lines.length);

// find top-level (indent 0) statement starts
const tops = [];
lines.forEach((l, i) => {
  if (/^(var|function|const|let|IIFE|\(function|window\.|document\.|\})/.test(l) && l.trim()) {
    tops.push([i + 1, l.slice(0, 90)]);
  }
});
console.log('--- INDENT0 LINES ---');
tops.forEach(t => console.log(t[0] + ' | ' + t[1]));
