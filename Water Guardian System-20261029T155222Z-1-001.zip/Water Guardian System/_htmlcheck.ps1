$ErrorActionPreference = 'Continue'
$root = 'f:\Water Guardian System'
$out  = Join-Path $root '_htmlcheck.txt'
$lines = New-Object System.Collections.Generic.List[string]

$lines.Add("=== HTML NESTING / STRUCTURE CHECK ===")

foreach ($hf in @('index.html','dashboard.html')) {
    $p = Join-Path $root $hf
    $text = Get-Content -LiteralPath $p -Raw

    # Pre-strip comments, doctype and data: URIs (they contain raw "<svg>" text).
    $text = [regex]::Replace($text, '<!--.*?-->', '', 'Singleline')
    $text = [regex]::Replace($text, '<!DOCTYPE[^>]*>', '', 'IgnoreCase')
    $text = [regex]::Replace($text, '(?:href|src)="data:[^"]*"', '', 'IgnoreCase')

    $lines.Add("")
    $lines.Add("-- $hf --")

    $stack = New-Object System.Collections.Generic.Stack[object]
    $errors = New-Object System.Collections.Generic.List[string]
    $void = @('meta','link','br','hr','img','input','path','circle','rect','line',
              'polyline','polygon','use','stop','source','col','area','base','embed','track','wbr')

    # Precompute line-start offsets so we can report real line numbers.
    $lineStarts = New-Object System.Collections.Generic.List[int]
    $lineStarts.Add(0)
    for ($i = 0; $i -lt $text.Length; $i++) {
        if ($text[$i] -eq "`n") { $lineStarts.Add($i + 1) }
    }
    function Get-LineNo([int]$pos) {
        $lo = 0; $hi = $lineStarts.Count - 1
        while ($lo -lt $hi) {
            $mid = [math]::Ceiling(($lo + $hi) / 2)
            if ($lineStarts[$mid] -le $pos) { $lo = $mid } else { $hi = $mid - 1 }
        }
        return $lo + 1
    }

    foreach ($m in [regex]::Matches($text, '<(/?)([a-zA-Z][a-zA-Z0-9]*)((?:"[^"]*"|[^>"])*?)(/?)>')) {
        $closing = $m.Groups[1].Value -eq '/'
        $tag = $m.Groups[2].Value.ToLower()
        $selfClose = $m.Groups[4].Value -eq '/'
        if ($void -contains $tag) { continue }
        if ($selfClose) { continue }

        $ln = Get-LineNo $m.Index

        if (-not $closing) {
            $stack.Push(@{ tag = $tag; line = $ln })
        } else {
            if ($stack.Count -eq 0) {
                $errors.Add(("  L{0}: </{1}> with nothing open" -f $ln, $tag))
            } else {
                $top = $stack.Pop()
                if ($top.tag -ne $tag) {
                    $errors.Add(("  L{0}: </{1}> closes <{2}> opened at L{3}" -f $ln, $tag, $top.tag, $top.line))
                }
            }
        }
    }

    while ($stack.Count -gt 0) {
        $t = $stack.Pop()
        $errors.Add(("  L{0}: <{1}> never closed" -f $t.line, $t.tag))
    }

    if ($errors.Count -eq 0) {
        $lines.Add("  OK - tags properly nested")
    } else {
        $lines.Add("  *** NESTING ERRORS: " + $errors.Count)
        foreach ($e in $errors) { $lines.Add($e) }
    }

    # Sibling check for the auth split layout
    if ($hf -eq 'index.html') {
        $brandPos = $text.IndexOf('class="auth__brand"')
        $brandEnd = $text.IndexOf('</section>', $brandPos)
        $panelPos = $text.IndexOf('class="auth__panel"')
        $lines.Add("")
        $lines.Add(("  brand @ {0}, brand </section> @ {1}, panel @ {2}" -f $brandPos, $brandEnd, $panelPos))
        if ($brandEnd -gt 0 -and $panelPos -gt $brandEnd) {
            $lines.Add("  OK - form panel is a SIBLING of the brand panel")
        } else {
            $lines.Add("  *** FORM PANEL IS NESTED INSIDE THE BRAND PANEL ***")
        }
    }
}

$lines | Out-File -LiteralPath $out -Encoding utf8
Write-Host "htmlcheck done"
