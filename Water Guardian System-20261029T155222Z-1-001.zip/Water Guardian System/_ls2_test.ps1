$ErrorActionPreference = 'Stop'
$work = 'C:\swg_ls2'
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory -Path $work -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $work 'assets\js') -Force | Out-Null

# subdir A seeds the session, subdir B reads it -> tests file:// origin sharing
New-Item -ItemType Directory -Path (Join-Path $work 'a') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $work 'b') -Force | Out-Null

Set-Content -LiteralPath "$work\a\set.html" -Value @'
<!DOCTYPE html><html><body><div id="r">PENDING</div><script>
try { localStorage.setItem('swg.session', JSON.stringify({name:'Demo User',email:'demo@gniot.net.in',role:'Facility Administrator'})); document.getElementById('r').textContent='SET_OK'; }
catch(e) { document.getElementById('r').textContent = 'LS_FAIL ' + e.message; }
</script></body></html>
'@ -Encoding utf8

Set-Content -LiteralPath "$work\b\read.html" -Value @'
<!DOCTYPE html><html><body><div id="r">PENDING</div><script>
var out = [];
try { out.push('LS=' + (localStorage.getItem('swg.session') || 'NULL')); } catch(e) { out.push('LS_FAIL ' + e.message); }
document.getElementById('r').textContent = out.join(' | ');
</script></body></html>
'@ -Encoding utf8

# page that loads app.js and reports any script error into the DOM
Set-Content -LiteralPath "$work\syntax.html" -Value @'
<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<div id="r">PENDING</div>
<script>
window.__errs = [];
window.onerror = function (m, s, l, c, e) {
  window.__errs.push((e && e.stack ? e.stack : String(m)));
  document.getElementById('r').textContent = 'ERRORS=' + window.__errs.join(' ||| ');
};
</script>
<script src="assets/js/app.js"></script>
<script>
document.getElementById('r').textContent = (window.__errs.length ? 'ERRORS=' + window.__errs.join(' ||| ') : 'NO_ERRORS; App=' + (typeof window.App) + '; Views=' + (typeof window.Views));
</script>
</body></html>
'@ -Encoding utf8

$chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
function Quote-Arg([string]$a) { if ($a -notmatch '[\s"]') { return $a }; return '"' + $a + '"' }
function Run-Chrome([string[]]$a, [string]$outFile, [string]$errFile) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $chrome
    $psi.Arguments = (($a | ForEach-Object { Quote-Arg $_ }) -join ' ')
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $so = $p.StandardOutput.ReadToEnd(); $se = $p.StandardError.ReadToEnd()
    $p.WaitForExit(60000) | Out-Null
    if (-not $p.HasExited) { try { $p.Kill() } catch {} }
    Set-Content -LiteralPath $outFile -Value ("EXIT=" + $p.ExitCode + "`n" + $so) -Encoding utf8
    Set-Content -LiteralPath $errFile -Value $se -Encoding utf8
}

$prof = "$work\p1"
$base = @('--headless=new','--disable-gpu','--no-sandbox','--disable-dev-shm-usage',"--user-data-dir=$prof",'--enable-logging=stderr','--v=0')

Run-Chrome ($base + @('--dump-dom','file:///C:/swg_ls2/a/set.html')) "$work\o1.txt" "$work\e1.txt"
Run-Chrome ($base + @('--dump-dom','file:///C:/swg_ls2/b/read.html')) "$work\o2.txt" "$work\e2.txt"
Run-Chrome ($base + @('--dump-dom','file:///C:/swg_ls2/syntax.html')) "$work\o3.txt" "$work\e3.txt"

foreach ($n in 1,2,3) {
    Write-Host "===== o$n ====="
    $t = Get-Content "$work\o$n.txt" -Raw -ErrorAction SilentlyContinue
    if ($t) {
        $m = [regex]::Match($t, '<div id="r">([^<]*)</div>')
        if ($m.Success) { Write-Host ("  RESULT: " + $m.Groups[1].Value) } else { Write-Host ("  (no #r match) len=" + $t.Length) }
    } else { Write-Host '  (no output file)' }
}
Write-Host '===== console from e3 ====='
Get-Content "$work\e3.txt" -ErrorAction SilentlyContinue | Select-String -Pattern 'CONSOLE|ERROR|Uncaught' | Select-Object -First 20
