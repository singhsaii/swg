$ErrorActionPreference = 'Continue'
$root = 'f:\Water Guardian System'
$out  = Join-Path $root '_probe2.txt'
$lines = New-Object System.Collections.Generic.List[string]

$lines.Add("=== RUNTIME HUNT ===")
$cands = @(
  'node','nodejs','npm','npx','bun','deno','yarn','pnpm','python','python3','py','pip',
  'git','php','ruby','java','javac','dotnet','go','rustc','cargo','flutter','dart',
  'tsc','vite','serve','http-server','live-server','chrome','msedge'
)
foreach ($c in $cands) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $lines.Add(("{0,-14} -> {1}" -f $c, $cmd.Source)) }
}
$lines.Add("")

$lines.Add("=== COMMON INSTALL LOCATIONS ===")
$paths = @(
 "$env:ProgramFiles\nodejs\node.exe",
 "${env:ProgramFiles(x86)}\nodejs\node.exe",
 "$env:LOCALAPPDATA\Programs\nodejs\node.exe",
 "$env:APPDATA\nvm",
 "$env:ProgramFiles\Git\cmd\git.exe",
 "$env:LOCALAPPDATA\Programs\Python",
 "C:\Python313\python.exe","C:\Python312\python.exe","C:\Python311\python.exe","C:\Python310\python.exe",
 "$env:LOCALAPPDATA\Microsoft\WindowsApps\python.exe"
)
foreach ($p in $paths) {
    $lines.Add(("{0,-60} {1}" -f $p, (Test-Path -LiteralPath $p)))
}
$lines.Add("")

$lines.Add("=== VS CODE EXTENSIONS (react/vite hints) ===")
$extRoot = Join-Path $env:USERPROFILE '.vscode\extensions'
if (Test-Path -LiteralPath $extRoot) {
    Get-ChildItem -LiteralPath $extRoot -Directory | Select-Object -ExpandProperty Name | ForEach-Object { $lines.Add("  $_") }
} else { $lines.Add("  none") }
$lines.Add("")

$lines.Add("=== PPTX THEME ===")
$themeFile = Join-Path $root '_pptx\ppt\theme\theme1.xml'
if (Test-Path -LiteralPath $themeFile) {
    $t = Get-Content -LiteralPath $themeFile -Raw
    $m = [regex]::Matches($t, '<a:(dk1|lt1|dk2|lt2|accent[1-6]|hlink|folHlink)>.*?(?:val="([0-9A-Fa-f]{6})"|lastClr="([0-9A-Fa-f]{6})")')
    foreach ($x in $m) {
        $val = if ($x.Groups[2].Success) { $x.Groups[2].Value } else { $x.Groups[3].Value }
        $lines.Add(("  {0,-10} #{1}" -f $x.Groups[1].Value, $val))
    }
    $fm = [regex]::Matches($t, 'typeface="([^"]*)"')
    $fonts = @{}
    foreach ($x in $fm) { if (-not $fonts.ContainsKey($x.Groups[1].Value)) { $fonts[$x.Groups[1].Value] = 1 } }
    $lines.Add("  FONTS: " + ($fonts.Keys -join ', '))
} else { $lines.Add("  no theme1.xml") }

$lines.Add("")
$lines.Add("=== PPTX MEDIA ===")
$media = Join-Path $root '_pptx\ppt\media'
if (Test-Path -LiteralPath $media) {
    Get-ChildItem -LiteralPath $media | ForEach-Object { $lines.Add(("  {0}  {1} bytes" -f $_.Name, $_.Length)) }
} else { $lines.Add("  none") }

$lines.Add("")
$lines.Add("=== SLIDE MASTER BACKGROUNDS / COLORS (srgbClr on slides) ===")
$slideDir = Join-Path $root '_pptx\ppt\slides'
$colors = @{}
Get-ChildItem -LiteralPath $slideDir -Filter 'slide*.xml' | ForEach-Object {
    $raw = Get-Content -LiteralPath $_.FullName -Raw
    foreach ($x in [regex]::Matches($raw, 'srgbClr val="([0-9A-Fa-f]{6})"')) {
        $v = $x.Groups[1].Value.ToUpper()
        if ($colors.ContainsKey($v)) { $colors[$v]++ } else { $colors[$v] = 1 }
    }
}
$colors.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object { $lines.Add(("  #{0}  x{1}" -f $_.Key, $_.Value)) }

$lines.Add("")
$lines.Add("=== SLIDE SIZE ===")
$pres = Join-Path $root '_pptx\ppt\presentation.xml'
if (Test-Path -LiteralPath $pres) {
    $p = Get-Content -LiteralPath $pres -Raw
    $sz = [regex]::Match($p, '<p:sldSz[^>]*>')
    $lines.Add("  " + $sz.Value)
}

$lines | Out-File -LiteralPath $out -Encoding utf8
Write-Host "probe2 done"
