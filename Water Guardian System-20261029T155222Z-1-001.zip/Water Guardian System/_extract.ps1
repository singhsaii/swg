$ErrorActionPreference = 'Continue'
$root = 'f:\Water Guardian System'
$pptx = Join-Path $root 'SMART WATER GUARDIAN.pptx'
$dest = Join-Path $root '_pptx'
$out  = Join-Path $root '_pptx_text.txt'

if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
New-Item -ItemType Directory -Path $dest -Force | Out-Null

Add-Type -AssemblyName System.IO.Compression.FileSystem
try {
    [System.IO.Compression.ZipFile]::ExtractToDirectory($pptx, $dest)
    Write-Host "extracted ok"
} catch {
    Write-Host ("extract error: " + $_.Exception.Message)
}

$lines = New-Object System.Collections.Generic.List[string]
$slideDir = Join-Path $dest 'ppt\slides'
if (Test-Path -LiteralPath $slideDir) {
    $slides = Get-ChildItem -LiteralPath $slideDir -Filter 'slide*.xml' | Sort-Object { [int]($_.BaseName -replace '\D','') }
    foreach ($s in $slides) {
        $lines.Add("")
        $lines.Add("========== " + $s.Name + " ==========")
        [xml]$x = Get-Content -LiteralPath $s.FullName -Raw
        $ns = New-Object System.Xml.XmlNamespaceManager($x.NameTable)
        $ns.AddNamespace('a','http://schemas.openxmlformats.org/drawingml/2006/main')
        $ns.AddNamespace('p','http://schemas.openxmlformats.org/presentationml/2006/main')
        $shapes = $x.SelectNodes('//p:sp', $ns)
        $i = 0
        foreach ($sp in $shapes) {
            $i++
            $name = $sp.SelectSingleNode('.//p:nvSpPr/p:cNvPr', $ns)
            $label = if ($name) { $name.GetAttribute('name') } else { '' }
            $paras = $sp.SelectNodes('.//a:p', $ns)
            $texts = New-Object System.Collections.Generic.List[string]
            foreach ($p in $paras) {
                $t = ($p.SelectNodes('.//a:t', $ns) | ForEach-Object { $_.InnerText }) -join ''
                if (-not [string]::IsNullOrWhiteSpace($t)) { $texts.Add($t) }
            }
            if ($texts.Count -gt 0) {
                $lines.Add("--- [shape $i] $label")
                foreach ($t in $texts) { $lines.Add("    $t") }
            }
        }
    }
} else {
    $lines.Add("NO SLIDES DIR")
    Get-ChildItem -LiteralPath $dest -Recurse -Force | ForEach-Object { $lines.Add($_.FullName) }
}

# notes slides
$notesDir = Join-Path $dest 'ppt\notesSlides'
if (Test-Path -LiteralPath $notesDir) {
    $lines.Add("")
    $lines.Add("################ NOTES ################")
    Get-ChildItem -LiteralPath $notesDir -Filter '*.xml' | Sort-Object { [int]($_.BaseName -replace '\D','') } | ForEach-Object {
        $lines.Add("--- " + $_.Name)
        $raw = Get-Content -LiteralPath $_.FullName -Raw
        $m = [regex]::Matches($raw, '<a:t>(.*?)</a:t>')
        foreach ($x in $m) { $lines.Add("    " + $x.Groups[1].Value) }
    }
}

$lines | Out-File -LiteralPath $out -Encoding utf8
Write-Host ("wrote " + $out)
