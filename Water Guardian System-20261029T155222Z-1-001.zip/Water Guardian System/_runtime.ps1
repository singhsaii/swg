$ErrorActionPreference = 'Continue'
$src  = 'f:\Water Guardian System'
$work = 'C:\swg_test'
$out  = 'f:\Water Guardian System\_runtime.txt'
$lines = New-Object System.Collections.Generic.List[string]

$chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'

if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path (Join-Path $work 'assets\css') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $work 'assets\js')  -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $work '_shots')  -Force | Out-Null

Copy-Item -LiteralPath (Join-Path $src 'index.html')    -Destination $work -Force
Copy-Item -LiteralPath (Join-Path $src 'dashboard.html') -Destination $work -Force
Copy-Item -Path (Join-Path $src 'assets\css\*.css')  -Destination (Join-Path $work 'assets\css') -Force
Copy-Item -Path (Join-Path $src 'assets\js\*.js')    -Destination (Join-Path $work 'assets\js')  -Force

# ---------------------------------------------------------------- helper
# NOTE 1: Chrome's --dump-dom writes the DOM to STDOUT.
# NOTE 2: Windows PowerShell 5.1 runs on .NET Framework, which has NO
#         ProcessStartInfo.ArgumentList (that is .NET Core 2.1+). Using it
#         silently drops every argument, so Chrome starts with no switches,
#         hands off to the running browser ("Opening in existing browser
#         session") and exits 0 with empty output. We therefore build a
#         correctly quoted argument STRING and set .Arguments instead.
function Quote-Arg([string]$a) {
    if ($a -notmatch '[\s"]') { return $a }
    return '"' + ($a -replace '(\\*)"','$1$1\"') + '"'
}

function Invoke-Chrome {
    param([string[]]$ChromeArgs, [string]$StdoutFile, [string]$StderrFile, [int]$TimeoutMs = 90000)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName  = $chrome
    $psi.Arguments = (($ChromeArgs | ForEach-Object { Quote-Arg $_ }) -join ' ')
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true

    $p = [System.Diagnostics.Process]::Start($psi)
    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    if (-not $p.WaitForExit($TimeoutMs)) { try { $p.Kill() } catch {} }
    $code = if ($p.HasExited) { $p.ExitCode } else { -1 }

    if ($StdoutFile) { Set-Content -LiteralPath $StdoutFile -Value $stdout -Encoding utf8 -NoNewline }
    if ($StderrFile) { Set-Content -LiteralPath $StderrFile -Value $stderr -Encoding utf8 -NoNewline }
    return $code
}

function New-Profile([string]$name) {
    $p = Join-Path $work ('prof_' + $name)
    if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue }
    return $p
}

$lines.Add('WORKDIR: ' + $work)
$lines.Add('CHROME:  ' + $chrome)

# ================================================================
# 0. localStorage / cookie availability on file://
# ================================================================
$lsHtml = @'
<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<div id="results">PENDING</div>
<script>
var out = [];
try { localStorage.setItem('swg.probe','v1'); out.push('LS_WRITE=' + localStorage.getItem('swg.probe')); }
catch(e) { out.push('LS_FAIL=' + e.message); }
try { document.cookie = 'swg.probe=v1'; out.push('COOKIE=' + document.cookie); }
catch(e) { out.push('COOKIE_FAIL=' + e.message); }
document.getElementById('results').textContent = out.join(' | ');
</script></body></html>
'@
Set-Content -LiteralPath (Join-Path $work 'ls.html') -Value $lsHtml -Encoding utf8

$prof = New-Profile 'ls'
$o = Join-Path $work '_ls_out.txt'; $e = Join-Path $work '_ls_err.txt'
$rc = Invoke-Chrome @('--headless=new','--disable-gpu','--no-sandbox','--disable-dev-shm-usage',
    ('--user-data-dir=' + $prof),'--dump-dom','file:///C:/swg_test/ls.html') $o $e
$lsDom = (Get-Content -LiteralPath $o -Raw -ErrorAction SilentlyContinue)
$lines.Add('')
$lines.Add('=== 0. STORAGE PROBE (file://) ===')
$lines.Add('exit ' + $rc)
$m = [regex]::Match($lsDom, '<div id="results">([^<]*)</div>')
$lines.Add('result: ' + $(if ($m.Success) { $m.Groups[1].Value } else { 'NO MATCH (dom len ' + $lsDom.Length + ')' }))

# ================================================================
# 1. LOGIN PAGE DOM
# ================================================================
$prof = New-Profile 'login'
$o = Join-Path $work '_dom_login.html'; $e = Join-Path $work '_err_login.txt'
$rc = Invoke-Chrome @('--headless=new','--disable-gpu','--no-sandbox','--disable-dev-shm-usage',
    '--virtual-time-budget=6000',('--user-data-dir=' + $prof),'--dump-dom',
    'file:///C:/swg_test/index.html') $o $e

$dom = (Get-Content -LiteralPath $o -Raw -ErrorAction SilentlyContinue)
$lines.Add('')
$lines.Add('=== 1. LOGIN PAGE ===')
$lines.Add('exit ' + $rc)
$lines.Add('dom length: ' + $dom.Length)
$errTxt = (Get-Content -LiteralPath $e -Raw -ErrorAction SilentlyContinue)
if ($errTxt -and $errTxt.Trim()) { $lines.Add('stderr: ' + $errTxt.Trim()) }

if ($dom.Length -gt 0) {
    $markers = [ordered]@{
        'login form present'    = 'id="login-form"'
        'signup form present'   = 'id="signup-form"'
        'login tab selected'    = 'id="tab-login"[^>]*aria-selected="true"'
        'signup form hidden'    = 'id="signup-form"[^>]*hidden'
        'brand headline'        = 'Every litre of campus water'
        'feature cards'         = 'auth__feature'
        'demo creds prefilled'  = 'demo@gniot\.net\.in'
        'password prefilled'    = 'id="login-password"[^>]*value="Water@1234"'
        'role picker'           = 'name="role"'
        'strength bars'         = 'strength__bar'
        'legal note'            = 'illustrative, not measured campus data'
        'segmented is-selected' = 'segmented__option is-selected'
    }
    foreach ($k in $markers.Keys) {
        $hit = [regex]::IsMatch($dom, $markers[$k])
        $lines.Add(("  {0,-24} {1}" -f $k, $(if ($hit) { 'PASS' } else { '*** FAIL ***' })))
    }
}

# ================================================================
# 2. LOGIN SCREENSHOT
# ================================================================
$prof = New-Profile 'shot'
$shot = Join-Path $work '_shots\01-login.png'
$o2 = Join-Path $work '_shot_out.txt'; $e2 = Join-Path $work '_shot_err.txt'
$rc2 = Invoke-Chrome @('--headless=new','--disable-gpu','--no-sandbox','--disable-dev-shm-usage',
    '--virtual-time-budget=5000','--window-size=1600,1000','--hide-scrollbars',
    ('--user-data-dir=' + $prof),('--screenshot=' + $shot),'file:///C:/swg_test/index.html') $o2 $e2
$lines.Add('')
$lines.Add('=== 2. LOGIN SCREENSHOT ===')
$lines.Add('exit ' + $rc2)
if (Test-Path -LiteralPath $shot) { $lines.Add('written: ' + (Get-Item -LiteralPath $shot).Length + ' bytes') }
else { $lines.Add('*** MISSING ***') }

$lines | Out-File -LiteralPath $out -Encoding utf8
Write-Host 'runtime done'

