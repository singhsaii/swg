$ErrorActionPreference = 'Stop'
$src = 'f:\Water Guardian System\assets\js\app.js'
$text = [System.IO.File]::ReadAllText($src)
$out = New-Object System.Collections.Generic.List[string]
$out.Add('CHARS=' + $text.Length + ' LINES=' + (($text -split "`n").Count))

# ---- JS-aware scanner: skip strings, template literals, comments, regex ----
$i = 0; $n = $text.Length
$stack = New-Object System.Collections.Generic.List[object]
$line = 1
$prevSignificant = ''
$errors = New-Object System.Collections.Generic.List[string]

while ($i -lt $n) {
    $c = $text[$i]
    if ($c -eq "`n") { $line++; $i++; continue }
    if ($c -eq ' ' -or $c -eq "`t" -or $c -eq "`r") { $i++; continue }

    if ($c -eq '/' -and $i + 1 -lt $n -and $text[$i+1] -eq '/') {
        while ($i -lt $n -and $text[$i] -ne "`n") { $i++ }
        continue
    }
    if ($c -eq '/' -and $i + 1 -lt $n -and $text[$i+1] -eq '*') {
        $i += 2
        while ($i -lt $n -and -not ($text[$i] -eq '*' -and $i+1 -lt $n -and $text[$i+1] -eq '/')) {
            if ($text[$i] -eq "`n") { $line++ }
            $i++
        }
        $i += 2
        continue
    }
    if ($c -eq "'" -or $c -eq '"') {
        $q = $c; $i++
        while ($i -lt $n) {
            if ($text[$i] -eq '\') { $i += 2; continue }
            if ($text[$i] -eq $q) { $i++; break }
            if ($text[$i] -eq "`n") { $line++ }
            $i++
        }
        $prevSignificant = 'str'
        continue
    }
    if ($c -eq '`') {
        $i++
        while ($i -lt $n) {
            if ($text[$i] -eq '\') { $i += 2; continue }
            if ($text[$i] -eq '`') { $i++; break }
            if ($text[$i] -eq "`n") { $line++ }
            $i++
        }
        $prevSignificant = 'str'
        continue
    }
    if ($c -eq '/' -and ($prevSignificant -eq '' -or $prevSignificant -eq 'op')) {
        $j = $i + 1; $inClass = $false; $ok = $false
        while ($j -lt $n) {
            $ch = $text[$j]
            if ($ch -eq '\') { $j += 2; continue }
            if ($ch -eq '[') { $inClass = $true }
            elseif ($ch -eq ']') { $inClass = $false }
            elseif ($ch -eq '/' -and -not $inClass) { $ok = $true; break }
            elseif ($ch -eq "`n") { break }
            $j++
        }
        if ($ok) {
            $i = $j + 1
            while ($i -lt $n -and $text[$i] -match '[gimsuyd]') { $i++ }
            $prevSignificant = 'val'
            continue
        }
    }
    if ($c -eq '(' -or $c -eq '[' -or $c -eq '{') {
        $stack.Add(@{ ch = $c; line = $line })
        $i++; $prevSignificant = 'op'; continue
    }
    if ($c -eq ')' -or $c -eq ']' -or $c -eq '}') {
        $want = @{ ')' = '('; ']' = '['; '}' = '{' }[$c]
        if ($stack.Count -eq 0) {
            $errors.Add("EXTRA CLOSER '$c' at line $line")
        } else {
            $top = $stack[$stack.Count - 1]
            if ($top.ch -ne $want) {
                $errors.Add("MISMATCH: '$c' at line $line vs '$($top.ch)' opened at line $($top.line)")
                while ($stack.Count -gt 0) {
                    $t = $stack[$stack.Count - 1]
                    $stack.RemoveAt($stack.Count - 1)
                    if ($t.ch -eq $want) { break }
                }
            } else {
                $stack.RemoveAt($stack.Count - 1)
            }
        }
        $i++; $prevSignificant = 'op'; continue
    }
    if ($c -match '[A-Za-z0-9_$]') {
        $start = $i
        while ($i -lt $n -and $text[$i] -match '[A-Za-z0-9_$]') { $i++ }
        $word = $text.Substring($start, $i - $start)
        if (@('return','typeof','new','delete','void','case','in','of','instanceof','do','else','yield','await') -contains $word) { $prevSignificant = 'kw' }
        else { $prevSignificant = 'val' }
        continue
    }
    $prevSignificant = 'op'
    $i++
}

$out.Add('=== SCAN ERRORS (' + $errors.Count + ') ===')
foreach ($e in $errors) { $out.Add($e) }
$out.Add('=== UNCLOSED OPENERS (' + $stack.Count + ') ===')
foreach ($s in $stack) { $out.Add("unclosed '$($s.ch)' opened at line $($s.line)") }

$out.Add('=== LANDMARKS ===')
foreach ($lm in @('Views.dashboard =','Views.zones =','Views.anomalies =','Views.report =','Views.reuse =','Views.analytics =','Views.settings =','global.App','global.Views','var breakdown')) {
    $idxs = @()
    $p = 0
    while (($p = $text.IndexOf($lm, $p)) -ge 0) {
        $idxs += (($text.Substring(0, $p) -split "`n").Count)
        $p += $lm.Length
    }
    $out.Add(("{0,-24} lines: {1}" -f $lm, ($idxs -join ',')))
}

$out.Add('=== LAST 10 LINES ===')
$all = $text -split "`n"
for ($k = [Math]::Max(0, $all.Count - 10); $k -lt $all.Count; $k++) { $out.Add(("{0}: {1}" -f ($k+1), $all[$k])) }

$out | Out-File -LiteralPath 'f:\Water Guardian System\_scan.txt' -Encoding utf8
Write-Output 'scan written'
