$ErrorActionPreference = 'Continue'
$root = 'f:\Water Guardian System'
$out  = Join-Path $root '_probe3.txt'
$lines = New-Object System.Collections.Generic.List[string]

Add-Type -AssemblyName System.Drawing

function Sample-Png($path, $points) {
    $bmp = New-Object System.Drawing.Bitmap($path)
    foreach ($p in $points) {
        $c = $bmp.GetPixel($p[0], $p[1])
        $lines.Add(("  {0} @({1},{2}) => #{3:X2}{4:X2}{5:X2}" -f (Split-Path $path -Leaf), $p[0], $p[1], $c.R, $c.G, $c.B))
    }
    $bmp.Dispose()
}

$lines.Add("=== image2.png (GNIOT logo) sampled colors ===")
$img2 = Join-Path $root '_pptx\ppt\media\image2.png'
if (Test-Path -LiteralPath $img2) {
    Sample-Png $img2 @(@(250,60), @(255,90), @(180,100), @(60,60), @(500,60), @(560,90), @(640,60), @(700,60), @(800,100), @(140,60))
}

$lines.Add("")
$lines.Add("=== slide1.xml structure (title slide) ===")
$s1 = Join-Path $root '_pptx\ppt\slides\slide1.xml'
if (Test-Path -LiteralPath $s1) {
    $raw = Get-Content -LiteralPath $s1 -Raw
    $lines.Add("  len=" + $raw.Length)
    foreach ($x in [regex]::Matches($raw, 'srgbClr val="([0-9A-Fa-f]{6})"')) { $lines.Add("  color #" + $x.Groups[1].Value.ToUpper()) }
    foreach ($x in [regex]::Matches($raw, 'schemeClr val="(\w+)"')) { $lines.Add("  scheme " + $x.Groups[1].Value) }
    foreach ($x in [regex]::Matches($raw, 'prstGeom prst="(\w+)"')) { $lines.Add("  geom " + $x.Groups[1].Value) }
}

$lines.Add("")
$lines.Add("=== slideMaster1 background ===")
$sm = Join-Path $root '_pptx\ppt\slideMasters\slideMaster1.xml'
if (Test-Path -LiteralPath $sm) {
    $raw = Get-Content -LiteralPath $sm -Raw
    foreach ($x in [regex]::Matches($raw, 'srgbClr val="([0-9A-Fa-f]{6})"')) { $lines.Add("  color #" + $x.Groups[1].Value.ToUpper()) }
    foreach ($x in [regex]::Matches($raw, 'schemeClr val="(\w+)"')) { $lines.Add("  scheme " + $x.Groups[1].Value) }
}

$lines.Add("")
$lines.Add("=== layout names ===")
$ld = Join-Path $root '_pptx\ppt\slideLayouts'
Get-ChildItem -LiteralPath $ld -Filter '*.xml' | ForEach-Object {
    $raw = Get-Content -LiteralPath $_.FullName -Raw
    $m = [regex]::Match($raw, '<p:cSld name="([^"]*)"')
    $lines.Add(("  {0}  name='{1}'" -f $_.Name, $m.Groups[1].Value))
}

$lines | Out-File -LiteralPath $out -Encoding utf8
Write-Host "probe3 done"
