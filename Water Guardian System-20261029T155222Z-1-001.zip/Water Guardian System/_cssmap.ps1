$ErrorActionPreference = 'Continue'
$root = 'f:\Water Guardian System'
$out  = Join-Path $root '_cssmap.txt'
$lines = New-Object System.Collections.Generic.List[string]

foreach ($cf in @('assets\css\tokens.css','assets\css\base.css','assets\css\components.css','assets\css\auth.css','assets\css\app.css','assets\css\dashboard.css')) {
    $p = Join-Path $root $cf
    $t = Get-Content -LiteralPath $p -Raw
    $raw = Get-Content -LiteralPath $p
    $lines.Add("")
    $lines.Add("===== $cf (" + $raw.Count + " lines) =====")

    $depth = 0
    $buf = ''
    $startLine = 0
    $inBlock = $false

    for ($i = 0; $i -lt $raw.Count; $i++) {
        $line = $raw[$i]
        $code = ($line -replace '/\*.*?\*/','') -replace '//.*$',''

        if (-not $inBlock) {
            $opens = ([regex]::Matches($code,'\{')).Count
            $closes = ([regex]::Matches($code,'\}')).Count

            if ($opens -gt 0) {
                $startLine = $i + 1
                $before = ($code -split '\{')[0].Trim()
                if ($before) { $buf = $before } else { $buf = '(anon)' }
                $depth += $opens
                if ($depth -eq 1) {
                    $lines.Add(("  L{0,-5} {1}" -f $startLine, $buf))
                }
                $depth -= $closes
                if ($depth -le 0) { $depth = 0 }
            } elseif ($closes -gt 0) {
                # stray closing brace -> orphaned
                $lines.Add(("  L{0,-5} *** STRAY CLOSE BRACE ***  {1}" -f ($i+1), $code.Trim()))
            }
        } else {
            $depth += ([regex]::Matches($code,'\{')).Count
            $depth -= ([regex]::Matches($code,'\}')).Count
            if ($depth -le 0) { $depth = 0 }
        }
    }
}

$lines | Out-File -LiteralPath $out -Encoding utf8
Write-Host "cssmap done"
